export const AppConstants = {
  response: {
    successResponse: {
      success: true,
    },
  },
};
