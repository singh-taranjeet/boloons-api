export interface PlayerType {
  id: string;
  score: number;
  name: string;
}
