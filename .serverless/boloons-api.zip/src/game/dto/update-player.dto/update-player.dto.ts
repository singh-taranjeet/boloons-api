export class UpdatePlayerDto {}
