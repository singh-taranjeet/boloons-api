export class StopGameDto {}
